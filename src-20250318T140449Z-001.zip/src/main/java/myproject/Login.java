package myproject;
import java.io.IOException;
import java.util.HashMap;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class Login extends HttpServlet{
	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,NullPointerException {
		HttpSession session=req.getSession();
		HashMap<String, String> mydetails = (HashMap<String, String>) session.getAttribute("mydetails");

		String storedemail=mydetails.get("E-mail Id:");
		String storedpassword=mydetails.get("Password:");
		String enteredemail=req.getParameter("email");
		String enteredpassword=req.getParameter("password");
		if(enteredemail.equals(storedemail))
		{
			if(enteredpassword.equals(storedpassword))
			{
				res.sendRedirect("welcome.jsp");
			}
			else
			{
				res.sendRedirect("login.jsp");
			}
			
		}
//		System.out.println(storedemail);
//		System.out.println(enteredemail);
//		System.out.println(storedpassword);
//		System.out.println(enteredpassword);
//		
		
			
	}

}
