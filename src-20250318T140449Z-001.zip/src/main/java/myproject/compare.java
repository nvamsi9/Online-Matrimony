package myproject;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@SuppressWarnings("serial")
public class compare extends HttpServlet {
	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException,NullPointerException, ServletException {
		HttpSession session=req.getSession();
		HashMap<String, String> mydetails = (HashMap<String, String>) session.getAttribute("mydetails");
		HashMap<String, String> person1 = new LinkedHashMap<>();
    	person1.put("Name", "Naveen");
    	person1.put("Gender", "MALE");
    	person1.put("DOB", "7.7.1980");
    	person1.put("Religion", "Hindu");
    	person1.put("Mother Tongue", "Telugu");
    	person1.put("Country living in","INDIA");
    	person1.put("Mobile number","9753124680");
    	person1.put("Residing state","Andra pradesh");
    	person1.put("City", "Guntur");
    	person1.put("Height","5.8ft");
    	person1.put("Weight","60kg");
    	person1.put("Education","B.Tech");
    	person1.put("Occupation", "Youtuber");
    	person1.put("Employed in","Others");
    	person1.put("Monthly income","1Lakh");
    	person1.put("Habits","No Smoking & Drinking");
    	person1.put("Food","Non veg");
    	person1.put("Interests","COOKING");
    	person1.put("Family type","Joint");
        session.setAttribute("person1", person1);
        session.getAttribute("person1");
        
    	HashMap<String, String> person2 = new LinkedHashMap<>();
    	person2.put("Name", "Mohan");
    	person2.put("Gender", "MALE");
    	person2.put("DOB", "19.5.1982");
    	person2.put("Religion", "Hindu");
    	person2.put("Mother Tongue", "Kannada");
    	person2.put("Country living in","INDIA");
    	person2.put("Mobile number","9538008359");
    	person2.put("Residing state","Karnataka");
    	person2.put("City", "Bangalore");
    	person2.put("Height","5.8ft");
    	person2.put("Weight","70kg");
    	person2.put("Education","Masters degree");
    	person2.put("Occupation", "Software Engineer");
    	person2.put("Employed in","Public");
    	person2.put("Monthly income","3Lakh");
    	person2.put("Habits","No Smoking & Drinking");
    	person2.put("Food"," veg");
    	person2.put("Interests","TRAVELLING");
    	person2.put("Family type","nuclear");
        session.setAttribute("person2", person2);
        session.getAttribute("person2");
        
    	HashMap<String, String> person3 = new LinkedHashMap<>();
    	person3.put("Name", "Jack");
    	person3.put("Gender", "MALE");
    	person3.put("DOB", "1.11.1982");
    	person3.put("Religion", "Christian");
    	person3.put("Mother Tongue", "Telugu");
    	person3.put("Country living in","INDIA");
    	person3.put("Mobile number","9538082779");
    	person3.put("Residing state","Andra pradesh");
    	person3.put("City", "Kurnool");
    	person3.put("Height","6 ft");
    	person3.put("Weight","90kg");
    	person3.put("Education","MBBS");
    	person3.put("Occupation", "Doctor");
    	person3.put("Employed in","public");
    	person3.put("Monthly income","5Lakh");
    	person3.put("Habits","No Smoking & Drinking");
    	person3.put("Food"," veg");
    	person3.put("Interests","SOCIAL SERVICE");
    	person3.put("Family type","nuclear");
        session.setAttribute("person3", person3);
        session.getAttribute("person3");
    
    	HashMap<String, String> person4 = new LinkedHashMap<>();
    	person4.put("Name", "Akash");
    	person4.put("Gender", "MALE");
    	person4.put("DOB", "29.2.1981");
    	person4.put("Religion", "Hindu");
    	person4.put("Mother Tongue", "Telugu");
    	person4.put("Country living in","INDIA");
    	person4.put("Mobile number","845982779");
    	person4.put("Residing state","Karnataka");
    	person4.put("City", "Hubli");
    	person4.put("Height","5.3 ft");
    	person4.put("Weight","80kg");
    	person4.put("Education"," B.tech ");
    	person4.put("Occupation", "Teacher");
    	person4.put("Employed in","private");
    	person4.put("Monthly income","1.5Lakh");
    	person4.put("Habits"," Smoking");
    	person4.put("Food","  Non veg");
    	person4.put("Interests","PHOTOGRAPHY");
    	person4.put("Family type","nuclear");
        session.setAttribute("person4", person4);
        session.getAttribute("person4");
    
    	HashMap<String, String> person5 = new LinkedHashMap<>();
    	person5.put("Name", "Sameer");
    	person5.put("Gender", "MALE");
    	person5.put("DOB", "1.1.1979");
    	person5.put("Religion", "Muslim");
    	person5.put("Mother Tongue", "Hindi");
    	person5.put("Country living in","INDIA");
    	person5.put("Mobile number","9876543210");
    	person5.put("Residing state","Andra pradesh");
    	person5.put("City", "Vijayawada");
    	person5.put("Height","6 ft");
    	person5.put("Weight","90kg");
    	person5.put("Education"," Inter ");
    	person5.put("Occupation", "Farmer");
    	person5.put("Employed in","private");
    	person5.put("Monthly income","2Lakh");
    	person5.put("Habits"," Smoking & Drinking");
    	person5.put("Food","  Non veg");
    	person5.put("Interests","TRAVELLING");
    	person5.put("Family type","nuclear");
        session.setAttribute("person5", person5);
        session.getAttribute("person5");
    
    	HashMap<String, String> person6 = new LinkedHashMap<>();
    	person6.put("Name", "Nithya");
    	person6.put("Gender", "FEMALE");
    	person6.put("DOB", "10.5.1983");
    	person6.put("Religion", "Hindu");
    	person6.put("Mother Tongue", "Telugu");
    	person6.put("Country living in","INDIA");
    	person6.put("Mobile number","9876556789");
    	person6.put("Residing state","Telangana");
    	person6.put("City", "  Hyderabad");
    	person6.put("Height","5.6 ft");
    	person6.put("Weight","60kg");
    	person6.put("Education"," B.tech discontuned ");
    	person6.put("Occupation", "Actress");
    	person6.put("Employed in","private");
    	person6.put("Monthly income","2Lakh");
    	person6.put("Habits","  No such Habits");
    	person6.put("Food","  Non veg");
    	person6.put("Interests","REELS");
    	person6.put("Family type","Joint");
        session.setAttribute("person6", person6);
        session.getAttribute("person6");
    
    	HashMap<String, String> person7 = new LinkedHashMap<>();
    	person7.put("Name", "Shreya");
    	person7.put("Gender", "FEMALE");
    	person7.put("DOB", "29.4.1985");
    	person7.put("Religion", "Hindu");
    	person7.put("Mother Tongue", "Telugu");
    	person7.put("Country living in","INDIA");
    	person7.put("Mobile number","7623156789");
    	person7.put("Residing state","Telangana");
    	person7.put("City", "  Warangal");
    	person7.put("Height","5.2 ft");
    	person7.put("Weight","60kg");
    	person7.put("Education"," B.tech ");
    	person7.put("Occupation", "YouTuber");
    	person7.put("Employed in","private");
    	person7.put("Monthly income","2Lakh");
    	person7.put("Habits","  No such Habits");
    	person7.put("Food","  Non veg");
    	person7.put("Interests","REELS");
    	person7.put("Family type","Nuclear");
        session.setAttribute("person7", person7);
        session.getAttribute("person7");
    
    	HashMap<String, String> person8 = new LinkedHashMap<>();
    	person8.put("Name", "Keerthi");
    	person8.put("Gender", "FEMALE");
    	person8.put("DOB", "2.12.1983");
    	person8.put("Religion", "Hindu");
    	person8.put("Mother Tongue", "Telugu");
    	person8.put("Country living in","INDIA");
    	person8.put("Mobile number","9538056789");
    	person8.put("Residing state","Telangana");
    	person8.put("City", "  karimnagar");
    	person8.put("Height","5.4 ft");
    	person8.put("Weight","70kg");
    	person8.put("Education"," M.tech ");
    	person8.put("Occupation", "Fashion Designing");
    	person8.put("Employed in","private");
    	person8.put("Monthly income","1Lakh");
    	person8.put("Habits","  No such Habits");
    	person8.put("Food","   veg");
    	person8.put("Interests","TRAVELLING");
    	person8.put("Family type","Joint");
        session.setAttribute("person8", person8);
        session.getAttribute("person8");
    
    	HashMap<String, String> person9 = new LinkedHashMap<>();
    	person9.put("Name", "Jessy");
    	person9.put("Gender", "FEMALE");
    	person9.put("DOB", "12.1.1984");
    	person9.put("Religion", "Christian");
    	person9.put("Mother Tongue", "Telugu");
    	person9.put("Country living in","INDIA");
    	person9.put("Mobile number","9538805678");
    	person9.put("Residing state","Kerala");
    	person9.put("City", "  kochi");
    	person9.put("Height","5.2 ft");
    	person9.put("Weight","80kg");
    	person9.put("Education"," B.tech ");
    	person9.put("Occupation", "Teacher");
    	person9.put("Employed in","private");
    	person9.put("Monthly income","1Lakh");
    	person9.put("Habits","  No such Habits");
    	person9.put("Food","   veg");
    	person9.put("Interests","TRAVELLING");
    	person9.put("Family type","Joint");
        session.setAttribute("person9", person9);
        session.getAttribute("person9");
    
    	HashMap<String, String> person10 = new LinkedHashMap<>();
    	person10.put("Name", "Adya");
    	person10.put("Gender", "FEMALE");
    	person10.put("DOB", "1.9.1984");
    	person10.put("Religion", "Hindu");
    	person10.put("Mother Tongue", "Tamil");
    	person10.put("Country living in","INDIA");
    	person10.put("Mobile number","9538105678");
    	person10.put("Residing state","Tamil nadu");
    	person10.put("City", "Coimbatore");
    	person10.put("Height","5.2 ft");
    	person10.put("Weight","90kg");
    	person10.put("Education"," 10th ");
    	person10.put("Occupation", "Nill");
    	person10.put("Employed in","others");
    	person10.put("Monthly income","Null");
    	person10.put("Habits","  No such Habits");
    	person10.put("Food","   Non veg");
    	person10.put("Interests","PHOTOGRAPHY");
    	person10.put("Family type","Joint");
        session.setAttribute("person10", person10);
		session.getAttribute("person10");
		HashMap<HashMap<String, String>, String> hashMap = new HashMap<HashMap<String, String>, String>();
        hashMap.put(person1, person1.get("Gender"));
        hashMap.put(person2, person2.get("Gender"));
        hashMap.put(person3, person3.get("Gender"));
        hashMap.put(person4, person4.get("Gender"));
        hashMap.put(person5, person5.get("Gender"));
        hashMap.put(person6, person6.get("Gender"));
        hashMap.put(person7, person7.get("Gender"));
        hashMap.put(person8, person8.get("Gender"));
        hashMap.put(person9, person9.get("Gender"));
        hashMap.put(person10, person10.get("Gender"));
        session.setAttribute("hashMap", hashMap);
        session.getAttribute("hashMap");
        HashMap<HashMap<String, String>, String> hashMap1 = new HashMap<HashMap<String, String>, String>();
        hashMap1.put(person1, person1.get("Interests"));
        hashMap1.put(person2, person2.get("Interests"));
        hashMap1.put(person3, person3.get("Interests"));
        hashMap1.put(person4, person4.get("Interests"));
        hashMap1.put(person5, person5.get("Interests"));
        hashMap1.put(person6, person6.get("Interests"));
        hashMap1.put(person7, person7.get("Interests"));
        hashMap1.put(person8, person8.get("Interests"));
        hashMap1.put(person9, person9.get("Interests"));
        hashMap1.put(person10, person10.get("Interests"));
        session.setAttribute("hashMap1", hashMap1);
		session.getAttribute("hashMap1");
		boolean matchFound =false;
		for (HashMap<String, String> key : hashMap.keySet()) 
		{
        	if(!mydetails.get("Gender:").equals(hashMap.get(key)))
        	{
        		for(HashMap<String,String> key1: hashMap1.keySet())
        		{
        			if(key1.equals(key))
        			{
        				if(mydetails.get("Interests:").equals(hashMap1.get(key1)))
        				{
        					System.out.println("**************************************************************************");
        					req.setAttribute("key", key);
        					for (String k : key.keySet()) {
                                System.out.println(k + " : " + key.get(k));
                                RequestDispatcher rd = req.getRequestDispatcher("compare.jsp");
                                rd.forward(req, res);
                            }
        					 matchFound = true;

        					
        				}
        			}
        		}
        	}
        }
		
		if (matchFound) {
			res.sendRedirect("compare.jsp");
		}
	}
	
}
