package myproject;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.*;
@SuppressWarnings("serial")
public class Register extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		HttpSession session=req.getSession();
		LinkedHashMap<String, String> mydetails = new LinkedHashMap<>();
        mydetails.put("Name:", req.getParameter("name"));
        mydetails.put("Gender:", req.getParameter("gender"));
        mydetails.put("Date of Birth:", req.getParameter("dateofbirth"));
        mydetails.put("Religion:", req.getParameter("religion"));
        mydetails.put("Mother Tongue:", req.getParameter("mothertongue"));
        mydetails.put("Country:", req.getParameter("country"));
        mydetails.put("Mobile Number:", req.getParameter("mobilenumber"));
        mydetails.put("State:", req.getParameter("state"));
        mydetails.put("City:", req.getParameter("city"));
        mydetails.put("Height:", req.getParameter("height"));
        mydetails.put("Weight:", req.getParameter("weight"));
        mydetails.put("Education:", req.getParameter("education"));
        mydetails.put("Occupation:", req.getParameter("occupation"));
        mydetails.put("Employed In:", req.getParameter("employedin"));
        mydetails.put("Income:", req.getParameter("income"));
        mydetails.put("Habits:", req.getParameter("habits"));
        mydetails.put("Food:", req.getParameter("food"));
        mydetails.put("Interests:", req.getParameter("interests"));
        mydetails.put("E-mail Id:", req.getParameter("email"));
        mydetails.put("Password:", req.getParameter("password"));

        session.setAttribute("mydetails", mydetails);
        res.sendRedirect("login.jsp");
	}
}
 