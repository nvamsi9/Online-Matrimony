package com.telusko;
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
public class sqServlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException
	{
		int k=(int)req.getAttribute("k");
		k=k*k;
		PrintWriter  out=res.getWriter();
		out.println("Result is "+k);
	}
}
